sudo apt-get install xdotool
sudo apt-get install mplayer
pip install rospkg
sudo apt install hackrf
